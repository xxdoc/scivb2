Title: Revelatek MDITabs Control v1.05 *BIG UPDATE*
Description: Revelatek MDI Tabs control provides you with the ability to have Visual Studio.NET, Office 2003 and Office 2000 style tabs. To use this control you don't have to write a single line of code you just need to put it on MDI form and that's all!
UPDATE: Check out comments bellow for update history.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=57301&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
