Title: cEditXP (Version 4.9.9)
Description: cEditXP is a new release of the VB cEdit 4 series. It is to a large extent totally rewritten. It now utilizes the ScintillaVB control to provide extensive support for code highlighting including folding, code sense and auto complete. 
This application uses RvMDITab, VB6VBATabControl, and SCIVB. I've included the source code for all 3. The credit's are included in the about box. For notes worth the VB6VBATabControl is written by Steve from VBAccelerator. The REVMDITabs is written by Andrea Batina and is available here. Both have some very minor modifications to correct problems interacting with eachother.
You can download a copy from my website at http://www.ceditmx.com/cx.zip if you wish to have the controls precompiled. 
I welcome comments and suggestions and constructive critisism. Thank you and enjoy.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66207&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
